# -*- coding: utf-8 -*-
"""
Created on Mon May 16 08:46:32 2022

@author: hu
"""
from model import TBHCNN, Variation1
from PyQt5.QtCore import pyqtSignal, QThread
import numpy as np
#import tensorflow.compat.v1 as tf
import tensorflow as tf
class TBWorker(QThread):
    epoch_signal = pyqtSignal(int)
    loss_signal = pyqtSignal(float)
    finish_signal = pyqtSignal()
    epoch_list=np.array([])
    loss_list=np.array([])
    train_steps = 0
    HR = np.array([])
    def __init__(self, loss_threshold, max_train_steps, band, K, rvectors_without_opposite, parent=None):
        super(TBWorker, self).__init__(parent)
        #设置工作状态与初始num数值
        self.graph=tf.Graph()
        self.sess=tf.Session(graph=self.graph)
        self.Optimizer=tf.train.AdamOptimizer(0.001)  #设置学习因子
        self.basis_added_step = 2                     #设置步进数
        self.loss_threshold=loss_threshold
        self.max_train_steps=max_train_steps
        self.tbhcnn=TBHCNN(self.graph)
        self.references = band
        self.kvectors = np.load(K)
        self.tbhcnn.read_training_set(self.references, self.kvectors)
        self.tbhcnn.define_TB_representation(rvectors_without_opposite)
        self.tbhcnn.reinitialize()
        self.working = True
        self.num = 0

    def __del__(self):
        #线程状态改变与线程终止
        self.working = False
        self.wait()

    def run(self):
         #self.epoch_signal.emit(file_str)
         #self.sleep(0.1)
         #self.loss_signal.emit(file_str)
         #self.sleep(0.1)
        with self.graph.as_default():
            while not self.HR:
                reproduces = self.tbhcnn.compute_bands()
                loss = tf.reduce_mean(tf.square(reproduces - self.tbhcnn.references))
                train = self.Optimizer.minimize(loss)
                init = tf.global_variables_initializer()
                self.sess.run(init)
                steps = 0
                self.loss_signal.emit(self.sess.run(loss))
                while (self.sess.run(loss) > self.loss_threshold) and (steps < self.max_train_steps):
                    self.sess.run(train)
                    self.train_steps += 1
                    steps += 1
                    self.epoch_signal.emit(int(steps/self.max_train_steps*100))
                    self.loss_signal.emit(self.sess.run(loss))
                    self.epoch_list=np.append(self.epoch_list, self.train_steps)
                    self.loss_list=np.append(self.loss_list, self.sess.run(loss))
                if self.sess.run(loss) > self.loss_threshold:
                    self.tbhcnn.H_size_added += self.basis_added_step
                    self.tbhcnn.reinitialize()
                else:
                    self.HR=self.sess.run(tf.cast(self.tbhcnn.HR, tf.float64))
                    break
            self.reproduce=self.sess.run(self.tbhcnn.reproduces)
            self.finish_signal.emit()
            
class V1Worker(QThread):
    epoch_signal = pyqtSignal(int)
    loss_signal = pyqtSignal(float)
    finish_signal = pyqtSignal()
    epoch_list=np.array([])
    loss_list=np.array([])
    train_steps = 0
    HR = np.array([])
    
    def __init__(self, loss_threshold, max_train_steps, band, K, rvectors_without_opposite, template, min_index, max_index, parent=None):
        super(V1Worker, self).__init__(parent)
        #设置工作状态与初始num数值
        self.graph=tf.Graph()
        self.sess=tf.Session(graph=self.graph)
        self.Optimizer=tf.train.AdamOptimizer(0.001)  #设置学习因子
        self.loss_threshold=loss_threshold
        self.max_train_steps=max_train_steps
        self.tbhcnn=Variation1(self.graph)
        self.references = band
        self.kvectors = np.load(K)
        self.template=template
        self.tbhcnn.read_training_set(self.references, self.kvectors, template, rvectors_without_opposite)
        self.tbhcnn.initialize()
        self.min_index=min_index
        self.max_index=max_index
        self.working = True
        self.num = 0
        self.flag=False

    def __del__(self):
        #线程状态改变与线程终止
        self.working = False
        self.wait()

    def run(self):
        with self.graph.as_default():
            reproduces = self.tbhcnn.compute_bands([self.min_index,self.max_index])
            loss2=tf.reduce_mean(tf.square(tf.cast(self.tbhcnn.HR, tf.float64)-tf.cast(self.tbhcnn.HR_init, tf.float64)))
            loss = tf.reduce_mean(tf.square(reproduces - self.tbhcnn.references))+loss2
            train = self.Optimizer.minimize(loss)
            init = tf.global_variables_initializer()
            self.sess.run(init)
            steps = 0
            self.loss_signal.emit(self.sess.run(loss))
            while (self.sess.run(loss) > self.loss_threshold) and (steps < self.max_train_steps):
                self.sess.run(train)
                self.train_steps += 1
                steps += 1
                self.epoch_signal.emit(int(steps/self.max_train_steps*100))
                self.loss_signal.emit(self.sess.run(loss))
                self.epoch_list=np.append(self.epoch_list, self.train_steps)
                self.loss_list=np.append(self.loss_list, self.sess.run(loss))
            if self.sess.run(loss) > self.loss_threshold:  #当运行的轮数超过最大值，当时仍然没有达到目标threshhold
                self.flag=True
            self.HR=self.sess.run(tf.cast(self.tbhcnn.HR, tf.float64))
            self.reproduce=self.sess.run(self.tbhcnn.reproduces)
            self.finish_signal.emit()
            