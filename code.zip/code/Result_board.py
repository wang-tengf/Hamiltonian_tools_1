# -*- coding: utf-8 -*-
"""
Created on Mon May 16 08:58:37 2022

@author: hu
"""
from PyQt5.QtWidgets import (QHBoxLayout, QVBoxLayout, QFrame, QPushButton, 
QLabel, QFileDialog)
from PyQt5.QtCore import pyqtSignal
from PyQt5.QtGui import QIcon
import numpy as np
img_path=str(np.loadtxt("./img_path.txt",dtype=str))

class ResultBoard(QFrame):
    save_fit_signal = pyqtSignal(str)
    save_h_signal = pyqtSignal(str)
    save_band_signal = pyqtSignal(str)
    plot_fit_signal = pyqtSignal(int)
    plot_h_signal = pyqtSignal(int)
    plot_band_signal = pyqtSignal(int)
    
    def __init__(self, parent):
        super().__init__(parent)
        self.initBoard()
 
    def initBoard(self):
        self.fit_plot_bttn = QPushButton(QIcon(img_path+'/plot.jpeg'),'Plot', self)
        self.fit_save_bttn = QPushButton(QIcon(img_path+'/download.jpeg'), 'Save', self)
        self.fit_plot_bttn.clicked[bool].connect(self.fit_send_msg)
        self.fit_save_bttn.clicked[bool].connect(self.fit_send_msg)
        
        self.label1 = QLabel(self)
        self.label1.setText("Fitting process:")
        self.label1.setGeometry(10, 10, 80, 30)
        
        self.H_plot_bttn = QPushButton(QIcon(img_path+'/matrix.jpeg'),'Plot', self)
        self.H_save_bttn = QPushButton(QIcon(img_path+'/download.jpeg'), 'Save', self)
        self.H_plot_bttn.clicked[bool].connect(self.h_send_msg)
        self.H_save_bttn.clicked[bool].connect(self.h_send_msg)
        
        self.label2 = QLabel(self)
        self.label2.setText("Hamiltonian matrix:")
        self.label2.setGeometry(10, 10, 80, 30)
        
        self.Band_plot_bttn = QPushButton(QIcon(img_path+'/band.jpeg'),'Plot', self)
        self.Band_save_bttn = QPushButton(QIcon(img_path+'/download.jpeg'), 'Save', self)
        self.Band_plot_bttn.clicked[bool].connect(self.band_send_msg)
        self.Band_save_bttn.clicked[bool].connect(self.band_send_msg)
        
        self.label3 = QLabel(self)
        self.label3.setText("Compare bands:")
        self.label3.setGeometry(10, 10, 80, 30)
        
        hbox1 = QHBoxLayout() #添加水平布局
        hbox1.addWidget(self.label1)
        hbox1.addWidget(self.fit_plot_bttn)
        hbox1.addWidget(self.fit_save_bttn)
        
        hbox2 = QHBoxLayout() #添加水平布局
        hbox2.addWidget(self.label2)
        hbox2.addWidget(self.H_plot_bttn)
        hbox2.addWidget(self.H_save_bttn)
        
        hbox3 = QHBoxLayout() #添加水平布局
        hbox3.addWidget(self.label3)
        hbox3.addWidget(self.Band_plot_bttn)
        hbox3.addWidget(self.Band_save_bttn)
 
        vbox = QVBoxLayout()
        vbox.addStretch(1)
        vbox.addLayout(hbox1)
        vbox.addStretch(1)
        vbox.addLayout(hbox2)
        vbox.addStretch(1)
        vbox.addLayout(hbox3)
        vbox.addStretch(1)
        
        self.setLayout(vbox)  
        self.show()
        
    def fit_send_msg(self, pressed):
        source = self.sender()
        if source.text() == "Plot":
            val = 1
            self.plot_fit_signal.emit(val) 
        else:           #让用户提供一个存储地址
            val = 0
            f=QFileDialog.getSaveFileName(self,
                                       r'创建.npy文件并保存',
                                       "./",
                                       r'NPY Files(*.npy)')
            fdir=f[0]
            self.save_fit_signal.emit(fdir)
    
    def h_send_msg(self, pressed):
        source = self.sender()
        if source.text() == "Plot":
            val = 1
            self.plot_h_signal.emit(val)
        else:
            val = 0 
            f=QFileDialog.getSaveFileName(self,
                                       r'创建.npy文件并保存',
                                       "./",
                                       r'NPY Files(*.npy)')
            fdir=f[0]
            self.save_h_signal.emit(fdir)
    
    def band_send_msg(self, pressed):
        source = self.sender()
        if source.text() == "Plot":
            val = 1
            self.plot_band_signal.emit(val)
        else:   
            val = 0 
            f=QFileDialog.getSaveFileName(self,
                                      r'创建.npy文件并保存',
                                      "./",
                                      r'NPY Files(*.npy)')
            fdir=f[0]
            self.save_band_signal.emit(fdir)
