# -*- coding: utf-8 -*-
"""
Created on Mon May 16 08:55:00 2022

@author: hu
"""

from PyQt5.QtWidgets import (QCheckBox,
QHBoxLayout, QVBoxLayout, QFrame, QPushButton, 
QSlider, QLabel, QFileDialog, QLineEdit, QMessageBox)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QIcon, QPixmap
from utils import is_number
import numpy as np
img_path=str(np.loadtxt("./img_path.txt",dtype=str))
        
class ParameterBoard(QFrame):
    
    slide_signal = pyqtSignal(int)
    check_signal = pyqtSignal(int)
    band_signal = pyqtSignal(str)
    K_signal = pyqtSignal(str)
    template_signal = pyqtSignal(str)
    precision_signal = pyqtSignal(float)
    plotband_signal = pyqtSignal()
    
    text=''
    min_E=''
    max_E=''
    min_index=''
    max_index=''
    
    def __init__(self, parent):
        super().__init__(parent)
        self.hauteur=30
        self.x_state=False
        self.y_state=False
        self.z_state=False
        self.min_epoch=3000
        self.max_epoch=10000
        self.initBoard()
        
        
 
    def initBoard(self):
        self.sld = QSlider(Qt.Horizontal, self)
        self.sld.setObjectName("slide")
        self.sld.setFocusPolicy(Qt.NoFocus)
        self.sld.setGeometry(30, 40, 100, 30)
        self.sld.setMinimum(self.min_epoch)
        self.sld.setMaximum(self.max_epoch)
        self.sld.setSingleStep(1000)
        self.sld.setPageStep(1000)
        self.sld.valueChanged[int].connect(self.changeValue)
        
        self.checklabel1 = QLabel(self)
        self.checklabel1.setPixmap(QPixmap(img_path+'/cross.jpeg').scaledToHeight(self.hauteur))
        self.checklabel2 = QLabel(self)
        self.checklabel2.setPixmap(QPixmap(img_path+'/cross.jpeg').scaledToHeight(self.hauteur))
        self.checklabel3 = QLabel(self)
        self.checklabel3.setPixmap(QPixmap(img_path+'/cross.jpeg').scaledToHeight(self.hauteur))
        
        self.label1 = QLabel(self)
        self.label1.setText("Max epochs:")
        self.label1.setGeometry(10, 10, 80, 30)
        
        self.epoch_label = QLabel(self)
        self.epoch_label.setText(str(self.min_epoch))
        self.epoch_label.setGeometry(10, 10, 80, 30)
        
        self.xcheckbox = QCheckBox('x axis', self)
        self.ycheckbox = QCheckBox('y axis', self)
        self.zcheckbox = QCheckBox('z axis', self)
        #连接事件
        self.xcheckbox.stateChanged.connect(self.checkActivated)
        self.ycheckbox.stateChanged.connect(self.checkActivated)
        self.zcheckbox.stateChanged.connect(self.checkActivated)
        
        self.label2 = QLabel(self)
        self.label2.setText("Dimension:")
        self.label2.setGeometry(10, 10, 80, 30)
        
        self.label3 = QLabel(self)
        self.label3.setText("Ab-initio band:")
        self.label3.setGeometry(10, 10, 80, 30)
        
        self.label4 = QLabel(self)
        self.label4.setText("K-points:")
        self.label4.setGeometry(10, 10, 80, 30)
        
        self.label5 = QLabel(self)
        self.label5.setText("Precision:")
        self.label5.setGeometry(10, 10, 80, 30)
        
        self.label6 = QLabel(self)
        self.label6.setText("Template*:")
        self.label6.setGeometry(10, 10, 80, 30)
        
        self.qle = QLineEdit(self)
        self.qle.textChanged[str].connect(self.linetextActivated)  
        
        openFile1 = QPushButton(QIcon(img_path+'/open.jpeg'), 'Open1', self)  #定义事件
        openFile1.setStatusTip('Open new File')   #在状态栏显示信息
        openFile1.clicked[bool].connect(self.showDialog)   #将事件连接到函数
        
        openFile2 = QPushButton(QIcon(img_path+'/open.jpeg'), 'Open2', self)  #定义事件
        openFile2.setStatusTip('Open new File')   #在状态栏显示信息
        openFile2.clicked[bool].connect(self.showDialog)   #将事件连接到函数
        
        openFile3 = QPushButton(QIcon(img_path+'/open.jpeg'), 'Open3', self)  #定义事件
        openFile3.setStatusTip('Open new File')   #在状态栏显示信息
        openFile3.clicked[bool].connect(self.showDialog)   #将事件连接到函数
        
        self.ok_bttn = QPushButton('OK', self)  #定义事件
        self.ok_bttn.setStatusTip('Confirm')   #在状态栏显示信息
        self.ok_bttn.clicked.connect(self.linetextActivated)   #将事件连接到函数
        
        hbox1 = QHBoxLayout() #添加水平布局
        hbox1.addWidget(self.label1)
        hbox1.addWidget(self.sld)
        hbox1.addWidget(self.epoch_label)
        
        hbox2 = QHBoxLayout() #添加水平布局
        hbox2.addWidget(self.label2)
        hbox2.addWidget(self.xcheckbox)
        hbox2.addWidget(self.ycheckbox)
        hbox2.addWidget(self.zcheckbox)
        
        hbox3 = QHBoxLayout() #添加水平布局
        hbox3.addWidget(self.label3)
        hbox3.addWidget(openFile1)
        hbox3.addWidget(self.checklabel1)
        
        hbox4 = QHBoxLayout() #添加水平布局
        hbox4.addWidget(self.label4)
        hbox4.addWidget(openFile2)
        hbox4.addWidget(self.checklabel2)
        
        
        hbox5 = QHBoxLayout() #添加水平布局
        hbox5.addWidget(self.label5)
        hbox5.addWidget(self.qle)
        hbox5.addWidget(self.ok_bttn)
        
        hbox6 = QHBoxLayout() #添加水平布局
        hbox6.addWidget(self.label6)
        hbox6.addWidget(openFile3)
        hbox6.addWidget(self.checklabel3)
        
        vbox = QVBoxLayout()
        vbox.addStretch(1)
        vbox.addLayout(hbox1)
        vbox.addStretch(1)
        vbox.addLayout(hbox2)
        vbox.addStretch(1)
        vbox.addLayout(hbox3)
        vbox.addStretch(1)
        vbox.addLayout(hbox4)
        vbox.addStretch(1)
        vbox.addLayout(hbox5)
        vbox.addStretch(1)
        vbox.addLayout(hbox6)
        vbox.addStretch(1)
        
        self.setLayout(vbox)  
        self.show()
        
    def showDialog(self, press):  #需要判断是从哪个按钮发出的
        source = self.sender()
        
        fname = QFileDialog.getOpenFileName(self, 'Open file', '/home') 
        if not (fname[0]==""):   #在输入文件路径不为空的情况下发送信号,否则什么都不做
            if(source.text()=="Open1"):
                self.band_signal.emit(fname[0])
                self.checklabel1.setPixmap(QPixmap(img_path+'/check.jpeg').scaledToHeight(self.hauteur))
            elif(source.text()=="Open2"):
                self.K_signal.emit(fname[0])
                self.checklabel2.setPixmap(QPixmap(img_path+'/check.jpeg').scaledToHeight(self.hauteur))
            else:
                self.template_signal.emit(fname[0])
                self.checklabel3.setPixmap(QPixmap(img_path+'/check.jpeg').scaledToHeight(self.hauteur))
        
                
    def changeValue(self, value):
        self.slide_signal.emit(value)  # 发出一个参数(整数)的信号
        self.epoch_label.setText(str(value))   #显示设置的epoch值
    
    def checkActivated(self, state):
        source = self.sender()
        if(source.text()=="x axis"):
            self.x_state=state
        elif(source.text()=="y axis"):
            self.y_state=state
        else:
            self.z_state=state
        if(self.x_state and not self.y_state and not self.z_state): #x axis
            self.check_signal.emit(0)
        elif(not self.x_state and self.y_state and not self.z_state): #y axis
            self.check_signal.emit(1)
        elif(not self.x_state and not self.y_state and self.z_state): #z axis
            self.check_signal.emit(2)
        elif(not self.x_state and self.y_state and self.z_state):  #yz plane
            self.check_signal.emit(3)
        elif(self.x_state and not self.y_state and self.z_state): #xz plane
            self.check_signal.emit(4)
        elif(self.x_state and self.y_state and not self.z_state): #xy plane
            self.check_signal.emit(5)
        elif(self.x_state and self.y_state and self.z_state):  #xyz
            self.check_signal.emit(6)
        else:                                                  #not check any one
            self.check_signal.emit(-1)
    
    def linetextActivated(self, msg):   #加一个确认按钮
        #需要判断text中的内容,并将其转化成小数形式,其余形式返回错误
        source = self.sender()
        if(source == self.ok_bttn):
            press=True
        else:
            press=False
            self.text=msg
        if press:
            if is_number(self.text):
                self.precision_signal.emit(eval(self.text))  
            else:
                QMessageBox.question(self, 'Error',
                "please enter a number correctly!", QMessageBox.Ok)
    