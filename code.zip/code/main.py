# -*- coding: utf-8 -*-
"""
Created on Thu Feb 17 13:58:09 2022

@author: hu
"""
import sys
import os
from PyQt5.QtWidgets import (QWidget, QMainWindow, QAction, QApplication, 
QDesktopWidget, QHBoxLayout, QVBoxLayout, QFrame, QSplitter, QPushButton,
QLabel, QLineEdit, QMessageBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon, QPixmap
import numpy as np
import matplotlib.pyplot as plt
from worker import TBWorker, V1Worker
from utils import Dialog, is_number, is_number2
from Param_board import ParameterBoard
from Result_board import ResultBoard
from Progress_board import ProgressBoard
img_path=str(np.loadtxt("./img_path.txt",dtype=str))

class Mainlayout(QWidget):
    
    
    def __init__(self):
        super().__init__()
 
        self.initUI()
 
    def initUI(self):
        hbox = QHBoxLayout(self)
 
        self.topleft = ParameterBoard(self)
        self.topleft.setFrameShape(QFrame.StyledPanel)
 
        self.topright = ResultBoard(self)
        self.topright.setFrameShape(QFrame.StyledPanel)
 
        self.bottom = ProgressBoard(self)
        self.bottom.setFrameShape(QFrame.StyledPanel)  #初始化三个frame对象
        
        splitter1 = QSplitter(Qt.Horizontal)  #横向分割
        splitter1.addWidget(self.topleft)
        splitter1.addWidget(self.topright)
 
        splitter2 = QSplitter(Qt.Vertical)   #竖向分割
        splitter2.addWidget(splitter1)
        splitter2.addWidget(self.bottom)
 
        hbox.addWidget(splitter2)
        self.setLayout(hbox)   #箱式布局

class Mainwindow(QMainWindow):
    
    def __init__(self):
        super().__init__()
        
        self.initUI()
        self.initParam()
        self.initParam_D()
        self.initDirec()
        
    def initDirec(self):
        path="./temp/"
        if(os.path.exists(path)):  #如果已经存在了相关文件夹
            pass
        else:              #如果不存在，则创建
            os.mkdir(path)
        
    def initUI(self):               
        
        self.mainlayout = Mainlayout()
        self.setCentralWidget(self.mainlayout)
 
        exitAction = QAction(QIcon(img_path+'/exit_icon.jpeg'), 
                             'Exit', self)
        exitAction.setShortcut('Ctrl+Q')
        exitAction.setStatusTip('Exit application')
        exitAction.triggered.connect(self.close)
        
        self.startAction = QAction(QIcon(img_path+'/start_icon.jpeg'), 
                             'Start', self)
        self.startAction.setShortcut('Ctrl+S')
        self.startAction.setStatusTip('Start fitting application')
        self.startAction.triggered.connect(self.start)
        
        pauseAction = QAction(QIcon(img_path+'/pause.jpeg'), 
                             'Pause', self)
        pauseAction.setShortcut('Ctrl+P')
        pauseAction.setStatusTip('Pausing application')
        pauseAction.triggered.connect(self.pause)
        
        resetAction = QAction(QIcon(img_path+'/reset.jpeg'), 
                             'Reset', self)
        resetAction.setShortcut('Ctrl+R')
        resetAction.setStatusTip('Restart the whole function')
        resetAction.triggered.connect(self.reset)
 
        self.statusBar()
 
        menubar = self.menuBar()
        fileMenu = menubar.addMenu('&File')
        fileMenu.addAction(exitAction)
 
        toolbar = self.addToolBar('Exit')
        toolbar.addAction(exitAction)
        toolbar = self.addToolBar('Start')  #必须实现
        toolbar.addAction(self.startAction)
        toolbar = self.addToolBar('Pause')  #可能很难实现,这个功能暂放
        toolbar.addAction(pauseAction)
        toolbar = self.addToolBar('Reset')  #最好实现,否则每次拟合一个物质都必须重开软件
        toolbar.addAction(resetAction)
        
        self.setGeometry(300, 300, 800, 700)
        self.center()
        self.setWindowTitle('Machine learning TB model')    
        self.setWindowIcon(QIcon(img_path+'/icon.jpeg')) # 创建一个QIcon对象并接收一个我们要显示的图片路径作为参数。
        self.Init_connection()
        self.show()
        
    #控制窗口显示在屏幕中心的方法    
    def center(self):
        
        #获得窗口
        qr = self.frameGeometry()
        #获得屏幕中心点
        cp = QDesktopWidget().availableGeometry().center()
        #显示到屏幕中心
        qr.moveCenter(cp)
        self.move(qr.topLeft())
    
    def Init_connection(self):
        #左上部分 信号发出者
        #slide会传送一个1000到3000的int值
        #combo会传送一个int值,只取1,2,3,表示对应维度数
        #band
        #K
        #precision
        #template
        #self.mainlayout.topleft.slide_signal ---- 控制epoch参数
        #self.mainlayout.topleft.combo_signal ---- 控制dimension参数
        #self.mainlayout.topleft.band_signal  ---- 控制第一性能带数据文件位置
        #self.mainlayout.topleft.K_signal     ---- 控制k点数据文件位置
        #self.mainlayout.topleft.precision_signal ---- 控制precision参数
        #self.mainlayout.topleft.template_signal  ---- 控制哈密顿量矩阵模版数据
  
        #右上部分 信号发出者（按钮按一下会发送一个1值）
        #self.mainlayout.topright.plot_fit_signal ---- 展示拟合过程
        #self.mainlayout.topright.save_fit_signal ---- 存储拟合过程
        #self.mainlayout.topright.plot_h_signal       ---- 展示哈密顿矩阵
        #self.mainlayout.topright.save_h_signal       ---- 存储哈密顿矩阵数据
        #self.mainlayout.topright.plot_band_signal   ---- 展示能带差别
        #self.mainlayout.topright.save_band_signal   ---- 存储能带数据

        #信号接收槽
        #self.mainlayout.bottom.show_progress ----  展示epoch数
        #self.mainlayout.bottom.show_loss     ----  展示拟合loss值
        #self.mainlayout.bottom.show_label   ----  展示目前状态
        
        #测试模块
        #self.mainlayout.bottom.show_label    ---- 同样可以用来检测信号是否生成正确
        #右上部分(结果)
        self.mainlayout.topright.plot_h_signal.connect(self.plot_h,Qt.QueuedConnection)
        self.mainlayout.topright.save_h_signal.connect(self.save_h,Qt.QueuedConnection)
        self.mainlayout.topright.plot_band_signal.connect(self.plot_band,Qt.QueuedConnection)
        self.mainlayout.topright.save_band_signal.connect(self.save_band,Qt.QueuedConnection)
        self.mainlayout.topright.plot_fit_signal.connect(self.plot_fit,Qt.QueuedConnection)
        self.mainlayout.topright.save_fit_signal.connect(self.save_fit,Qt.QueuedConnection)
        #左上部分(参数)
        self.mainlayout.topleft.slide_signal.connect(self.getEpoch,Qt.QueuedConnection)
        self.mainlayout.topleft.check_signal.connect(self.getDimension,Qt.QueuedConnection)
        self.mainlayout.topleft.band_signal.connect(self.getBand,Qt.QueuedConnection)
        self.mainlayout.topleft.K_signal.connect(self.getK,Qt.QueuedConnection)
        self.mainlayout.topleft.precision_signal.connect(self.getPrecision,Qt.QueuedConnection)
        self.mainlayout.topleft.template_signal.connect(self.getTemplate,Qt.QueuedConnection)
    
    def initParam(self):
        self.epoch=-1
        self.epoch_state=False
        self.dimension=-1
        self.dimension_state=False
        self.band=""
        self.band_state=False
        self.k=""
        self.k_state=False
        self.precision=0.0
        self.precision_state=False
        self.template=""
        self.template_state=False
        self.finish_state=False
        self.select_state=False
        
    def initParam_D(self):
        self.D1_t1=False
        self.D1_t2=False
        self.D2_t1=False
        self.D2_t2=False
        self.press1=False
        self.press2=False
        self.press3=False
        self.press4=False
        
    #菜单栏(开始,暂停,重置)
    def start(self):  #需要判断所有必需的参数是否都齐了
    #如果所有的参数都齐了
        if not self.epoch_state:   #如果用户m没滑动epoch滑动条,设置epoch为默认值
            self.epoch=self.mainlayout.topleft.min_epoch
            self.epoch_state=True 
   
        if(self.epoch_state and self.dimension_state and self.band_state
           and self.k_state and self.precision_state):  
            self.mainlayout.bottom.show_label(1)  #processing
            
            if(self.template_state):  #进入变式一分支
                self.fitting2(self.precision, self.epoch, self.reference, self.k, self.rvectors_without_opposite, self.min_index, self.max_index)
            else:                     #进入原版分支
                self.fitting1(self.precision, self.epoch, self.reference, self.k, self.rvectors_without_opposite)
        
        else:
            self.parameter_error()
        
    def pause(self):
        self.mainlayout.bottom.show_label(2)  #paused
        
    def reset(self):      #需要重置precision, combo, slide(可以不做)
        self.initParam()   #重置各种参数状态
        self.mainlayout.topleft.checklabel1.setPixmap(QPixmap(img_path+'/cross.jpeg').scaledToHeight(self.mainlayout.topleft.hauteur))
        self.mainlayout.topleft.checklabel2.setPixmap(QPixmap(img_path+'/cross.jpeg').scaledToHeight(self.mainlayout.topleft.hauteur))
        self.mainlayout.topleft.checklabel3.setPixmap(QPixmap(img_path+'/cross.jpeg').scaledToHeight(self.mainlayout.topleft.hauteur))
        self.mainlayout.bottom.show_label(0)  #重新回到setting
        self.mainlayout.bottom.show_loss(0)  #重新回到0
        self.mainlayout.bottom.show_progress(0)  #重新回到0%
        
        self.mainlayout.topleft.qle.setText("")
        self.mainlayout.topleft.sld.setValue(self.mainlayout.topleft.min_epoch)
        self.mainlayout.topleft.xcheckbox.setCheckState(False)
        self.mainlayout.topleft.ycheckbox.setCheckState(False)
        self.mainlayout.topleft.zcheckbox.setCheckState(False)
    
    def closeEvent(self, event):

        reply = QMessageBox.question(self, 'Message',
                                     "Are you sure to quit?", QMessageBox.Yes |
                                     QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()
            
    def errorbox(self, text):
        QMessageBox.question(self, 'Error!',
                                     "Parameter Absence: "+text)
            
    def getEpoch(self, val):
        self.epoch=val
        self.epoch_state=True
        
    def getDimension(self,val):
        if(val == -1):
            self.dimension_state=False
            self.mainlayout.bottom.show_rvector("...")
        else: 
            self.dimension_state=True
            self.dimension=val
            self.rvectors_without_opposite = np.array(self.rvector(self.dimension),dtype=np.int32)
            self.mainlayout.bottom.show_rvector(self.rvectors_without_opposite)
        
    def getBand(self, addr):   #在此处展示提供的能带，并跳出对话框，从而让用户选择目标拟合能带
        self.band=addr
        self.reference=np.load(addr)
        self.band_state=False
        self.initParam_D()
        self.dialog=Dialog(self.band_state)
        
        self.scale_bands(self.reference,99999,-99999)
        
        self.label = QLabel(self)
        self.label.setPixmap(QPixmap("./temp/temp.jpg"))
    
        self.label1 = QLabel(self)
        self.label1.setText("Min indexs:")
        self.label1.setGeometry(10, 10, 80, 30)
        
        self.label2 = QLabel(self)
        self.label2.setText("Max indexs:")
        self.label2.setGeometry(10, 10, 80, 30)
        
        self.label3 = QLabel(self)
        self.label3.setText("Min energy:")
        self.label3.setGeometry(10, 10, 80, 30)
        
        self.label4 = QLabel(self)
        self.label4.setText("Max energy:")
        self.label4.setGeometry(10, 10, 80, 30)
        
        self.max_linetxt=QLineEdit(self)
        self.max_linetxt.textChanged[str].connect(self.linetextActivated)
        
        self.min_linetxt=QLineEdit(self)
        self.min_linetxt.textChanged[str].connect(self.linetextActivated)
        
        self.max_E_linetxt=QLineEdit(self)
        self.max_E_linetxt.textChanged[str].connect(self.linetextActivated)
        
        self.min_E_linetxt=QLineEdit(self)
        self.min_E_linetxt.textChanged[str].connect(self.linetextActivated)
        
        hbox1 = QHBoxLayout() #添加水平布局
        hbox1.addWidget(self.label1)
        hbox1.addStretch(1)
        hbox1.addWidget(self.min_linetxt)
        hbox1.addStretch(1)
        hbox1.addWidget(self.label2)
        hbox1.addStretch(1)
        hbox1.addWidget(self.max_linetxt)
        
        hbox4 = QHBoxLayout() #添加水平布局
        hbox4.addWidget(self.label3)
        hbox4.addStretch(1)
        hbox4.addWidget(self.min_E_linetxt)
        hbox4.addStretch(1)
        hbox4.addWidget(self.label4)
        hbox4.addStretch(1)
        hbox4.addWidget(self.max_E_linetxt)
        
        hbox2 = QHBoxLayout() #添加水平布局
        hbox2.addStretch(1)
        hbox2.addWidget(self.label)
        hbox2.addStretch(1)
        
        hbox3 = QHBoxLayout() #添加水平布局
        hbox3.addStretch(1)
        self.btn = QPushButton("ok",self.dialog)
        self.btn.clicked.connect(self.linetextActivated)   #将事件连接到函数
        hbox3.addWidget(self.btn)
        hbox3.addStretch(1)
        
        hbox5 = QHBoxLayout() #添加水平布局
        hbox5.addStretch(1)
        self.btn2 = QPushButton("ok",self.dialog)
        self.btn2.clicked.connect(self.linetextActivated)   #将事件连接到函数
        hbox5.addWidget(self.btn2)
        hbox5.addStretch(1)
        
        vbox = QVBoxLayout()
        vbox.addStretch(1)
        vbox.addLayout(hbox2)
        vbox.addStretch(1)
        vbox.addLayout(hbox4)
        vbox.addStretch(1)
        vbox.addLayout(hbox5)
        vbox.addStretch(1)
        vbox.addLayout(hbox1)
        vbox.addStretch(1)
        vbox.addLayout(hbox3)
        vbox.addStretch(1)
        self.dialog.setWindowTitle("Reference bands selection")
        self.dialog.setWindowModality(Qt.ApplicationModal)
        self.dialog.setLayout(vbox)  
        self.dialog.show()
        self.dialog.exec_()
        self.band_state=self.dialog.state
        if(self.band_state): #选择了下标
            self.reference = self.reference[:,self.min_refer_index:self.max_refer_index]
        else:    #没有选择下标,选择了退出
            self.mainlayout.topleft.checklabel1.setPixmap(QPixmap(img_path+'/cross.jpeg').scaledToHeight(self.mainlayout.topleft.hauteur))
        self.num_fitband=self.reference.shape[1]  #可以拿来参考的能带
        
    def getK(self,addr):
        self.k=addr
        self.k_state=True
        
    def getPrecision(self,val):
        self.precision=val
        self.precision_state=True
        
    def getTemplate(self, addr):
        self.template=np.load(addr)
        self.num_wholeband=self.template.shape[1]  #得到总的能带数量
        self.judge_num_error()
        if(self.template_state):
            if(self.k_state and self.dimension_state and self.band_state):
                self.compute_bands()
                self.template_state=False   #尚未选择能带,置状态为False
                self.initParam_D()
                self.dialog2=Dialog(self.template_state)
                
                self.scale_bands(self.bands_reproduce,99999,-99999)
                
                self.label = QLabel(self)
                self.label.setPixmap(QPixmap("./temp/temp.jpg"))
            
                self.label1 = QLabel(self)
                self.label1.setText("Min indexs:")
                self.label1.setGeometry(10, 10, 80, 30)
                
                self.label2 = QLabel(self)
                self.label2.setText("Max indexs:")
                self.label2.setGeometry(10, 10, 80, 30)
                
                self.label3 = QLabel(self)
                self.label3.setText("Min energy:")
                self.label3.setGeometry(10, 10, 80, 30)
                
                self.label4 = QLabel(self)
                self.label4.setText("Max energy:")
                self.label4.setGeometry(10, 10, 80, 30)
                
                self.max_linetxt=QLineEdit(self)
                self.max_linetxt.textChanged[str].connect(self.linetextActivated2)
                
                self.min_linetxt=QLineEdit(self)
                self.min_linetxt.textChanged[str].connect(self.linetextActivated2)
                
                self.max_E_linetxt=QLineEdit(self)
                self.max_E_linetxt.textChanged[str].connect(self.linetextActivated2)
                
                self.min_E_linetxt=QLineEdit(self)
                self.min_E_linetxt.textChanged[str].connect(self.linetextActivated2)
                
                hbox1 = QHBoxLayout() #添加水平布局
                hbox1.addWidget(self.label1)
                hbox1.addStretch(1)
                hbox1.addWidget(self.min_linetxt)
                hbox1.addStretch(1)
                hbox1.addWidget(self.label2)
                hbox1.addStretch(1)
                hbox1.addWidget(self.max_linetxt)
                
                hbox4 = QHBoxLayout() #添加水平布局
                hbox4.addWidget(self.label3)
                hbox4.addStretch(1)
                hbox4.addWidget(self.min_E_linetxt)
                hbox4.addStretch(1)
                hbox4.addWidget(self.label4)
                hbox4.addStretch(1)
                hbox4.addWidget(self.max_E_linetxt)
                
                hbox2 = QHBoxLayout() #添加水平布局
                hbox2.addStretch(1)
                hbox2.addWidget(self.label)
                hbox2.addStretch(1)
                
                hbox3 = QHBoxLayout() #添加水平布局
                hbox3.addStretch(1)
                self.btn = QPushButton("ok",self.dialog2)
                self.btn.clicked.connect(self.linetextActivated2)   #将事件连接到函数
                hbox3.addWidget(self.btn)
                hbox3.addStretch(1)
                
                hbox5 = QHBoxLayout() #添加水平布局
                hbox5.addStretch(1)
                self.btn2 = QPushButton("ok",self.dialog2)
                self.btn2.clicked.connect(self.linetextActivated2)   #将事件连接到函数
                hbox5.addWidget(self.btn2)
                hbox5.addStretch(1)
                
                vbox = QVBoxLayout()
                vbox.addStretch(1)
                vbox.addLayout(hbox2)
                vbox.addStretch(1)
                vbox.addLayout(hbox4)
                vbox.addStretch(1)
                vbox.addLayout(hbox5)
                vbox.addStretch(1)
                vbox.addLayout(hbox1)
                vbox.addStretch(1)
                vbox.addLayout(hbox3)
                vbox.addStretch(1)
                self.dialog2.setWindowTitle("Fitting bands selection")
                self.dialog2.setWindowModality(Qt.ApplicationModal)
                self.dialog2.setLayout(vbox)  
                self.dialog2.show()
                self.dialog2.exec_()
                self.template_state=self.dialog2.state
                if(self.template_state): #选择了下标
                    pass
                else:    #没有选择下标,选择了退出
                    self.mainlayout.topleft.checklabel3.setPixmap(QPixmap(img_path+'/cross.jpeg').scaledToHeight(self.mainlayout.topleft.hauteur))
    
            else:                     #参数不全
                self.parameter_error2()  
                self.mainlayout.topleft.checklabel3.setPixmap(QPixmap(img_path+'/cross.jpeg').scaledToHeight(self.mainlayout.topleft.hauteur))
        else:
            pass
        
    def parameter_error(self):
        if not self.dimension_state:
            self.errorbox("Dimension")
        elif not self.band_state:
            self.errorbox("Band")
        elif not self.k_state:
            self.errorbox("K_points")
        elif not self.precision_state:
            self.errorbox("Precision")
            
    def parameter_error2(self):
        if not self.template_state :
            self.errorbox("Template")
        elif not self.band_state:
            self.errorbox("Band")
        elif not self.k_state:
            self.errorbox("K_points")
        else:
            self.errorbox("Dimension")
            
    def judge_num_error(self):
        if(self.num_wholeband < self.num_fitband):
            QMessageBox.question(self, 'Band number error!',
                                         "The template band number is less than the fitting band number!")
            self.reset()  #重启整个参数设置
        else:
            self.template_state=True

    def processing_error(self):  #在处理过程中要求结果,提示用户等待运算完成
        QMessageBox.question(self, 'Please Wait!',
                                     "Processing!")
            
    def save_fit(self, addr):
        if(self.epoch_state and self.dimension_state and self.band_state
           and self.k_state and self.precision_state):  
            if(self.finish_state):
                np.save(addr,self.worker.loss_list)   
            else:
                self.processing_error()
        else:
            self.parameter_error()
       
    def save_h(self, addr):
        if(self.epoch_state and self.dimension_state and self.band_state
           and self.k_state and self.precision_state):  
            if(self.finish_state):
                np.save(addr,self.worker.HR)  
            else:
                self.processing_error()
        else:
            self.parameter_error()
        
    def save_band(self, addr):
        if(self.epoch_state and self.dimension_state and self.band_state
           and self.k_state and self.precision_state):  
            if(self.finish_state):
                np.save(addr,self.worker.reproduce)
            else:
                self.processing_error()
        else:
            self.parameter_error()
    
    def plot_fit(self, press):
        if(self.epoch_state and self.dimension_state and self.band_state
           and self.k_state and self.precision_state):  
            if(self.finish_state):
                plt.close()
                plt.plot(self.worker.epoch_list, self.worker.loss_list, color='r', label='loss_curve')
                plt.show()  
            else:
                self.processing_error()
        else:
            self.parameter_error()
        
    def plot_h(self, press):
        if(self.epoch_state and self.dimension_state and self.band_state
           and self.k_state and self.precision_state):  
            if(self.finish_state):
                self.plt_H()  
            else:
                self.processing_error()
        else:
            self.parameter_error()
        
    def plot_band(self, press):
        if(self.epoch_state and self.dimension_state and self.band_state
           and self.k_state and self.precision_state):  
            if(self.finish_state):
                self.plt_bands()
            else:
                self.processing_error()
        else:
            self.parameter_error()
        
    def fitting1(self, loss_threshold, max_train_steps, band, K, rvectors_without_opposite):
        self.worker=TBWorker(loss_threshold, max_train_steps, band, K, rvectors_without_opposite)
        self.worker.epoch_signal.connect(self.mainlayout.bottom.show_progress)
        self.worker.loss_signal.connect(self.mainlayout.bottom.show_loss)
        self.worker.finish_signal.connect(self.finish_event)
        self.worker.start()
       
    
    def fitting2(self, loss_threshold, max_train_steps, band, K, rvectors_without_opposite, min_index, max_index):
        self.worker=V1Worker(loss_threshold, max_train_steps, band, K, rvectors_without_opposite, self.template, min_index, max_index)
        self.worker.epoch_signal.connect(self.mainlayout.bottom.show_progress)
        self.worker.loss_signal.connect(self.mainlayout.bottom.show_loss)
        self.worker.finish_signal.connect(self.finish_event)
        self.worker.start()
        
    def rvector(self,dimension):
        if (dimension == 0):    #x axis
            rvec=[[0, 0, 0], [1, 0, 0]]
        elif(dimension == 1):   #y axis
            rvec=[[0, 0, 0], [0, 1, 0]]
        elif (dimension == 2):    #z axis
            rvec=[[0, 0, 0], [0, 0, 1]]
        elif(dimension == 3):    #yz plane
            rvec=[[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, -1], [0, 1, 0]]
        elif(dimension == 4):    #xz plane
            rvec=[[0, 0, 0], [0, 0, 1], [1, 0, 1], [1, 0, -1], [1, 0, 0]]
        elif(dimension == 5):    #xy plane
            rvec=[[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, -1, 0], [1, 0, 0]]
        else:
            rvec= [[0, 0, 0], [0, 0, 1], [0, 1, 1],
                             [0, 1, -1], [1, 0, 0], [1, 0, 1],
                             [1, 1, 0], [1, 0, -1], [1, -1, 0],
                             [0, 1, 0], [1, 1, -1], [1, -1, 1],
                             [-1, 1, 1], [1, 1, 1]]
        return rvec
    
    def finish_event(self):
        self.mainlayout.bottom.show_label(3)  #finished
        self.finish_state=True
        
    def plt_bands(self):
        plt.close()
        bands_reference=self.worker.references
        bands_reproduce=self.worker.reproduce
        k_points=self.worker.kvectors
        num_k, num_b = bands_reference.shape
        x_points = np.arange(k_points.shape[0])

        for i in range(num_b):
            plt.plot(x_points, bands_reference[:, i], color='b', label='reference')
            plt.plot(x_points, bands_reproduce[:, i], color='r', ls='--', label='reproduction')

        plt.xlim(x_points[0], x_points[-1])
        plt.ylim(np.min(bands_reference) - 0.5, np.max(bands_reference) + 0.5)

        font = {'family': 'Times New Roman',
                'weight': 'normal',
                'size': 12,
                }
        
        from collections import OrderedDict
        handles, labels = plt.gca().get_legend_handles_labels()
        by_label = OrderedDict(zip(labels, handles))
        plt.legend(by_label.values(), by_label.keys(), prop=font) 
        plt.show()
        
    def plt_H(self):
        plt.close()
        num_hamiton = self.worker.HR.shape[0]
        for i in range(num_hamiton):
            plt.matshow(self.worker.HR[i], cmap=plt.cm.Blues)
            plt.colorbar()
            loc = 'left'
            font_dict = {'fontsize': 14,
                         'fontweight': 8.2,
                         'verticalalignment': 'baseline',
                         'horizontalalignment': loc}
            plt.title("{} {}".format('H' + str(i + 1), "Hamilton"), fontdict=font_dict, loc=loc)

        plt.show()
            
    def parameter_error3(self):
        QMessageBox.question(self, 'Selected index error!',
                                     "Mismatching with existing reference band!")
    
    def plt_single_bands(self, band):
        num_k, num_b = band.shape
        x_points = np.arange(num_k)

        for i in range(num_b):
            plt.plot(x_points, band[:, i], color='b', label='reference')

        plt.xlim(x_points[0], x_points[-1])
        plt.ylim(np.min(band) - 0.5, np.max(band) + 0.5)

        font = {'family': 'Times New Roman',
                'weight': 'normal',
                'size': 12,
                }
        
        from collections import OrderedDict
        handles, labels = plt.gca().get_legend_handles_labels()
        by_label = OrderedDict(zip(labels, handles))
        plt.legend(by_label.values(), by_label.keys(), prop=font) 
        plt.show()
        
    def compute_bands(self):
        H_template = self.template
        kpoints = np.load(self.k)
        rvector = self.rvectors_without_opposite
        k=kpoints
        Energy=np.array([]) 
        num_H=H_template.shape[0]
        num_band = H_template.shape[1]
        num_K=kpoints.shape[0]
        for i in range(num_K):
            H=H_template[0]
            for n in range(num_H-1):
                H = np.exp(1j*np.dot(k[i],rvector[n+1]))*H_template[n+1] + H + np.exp(-1j*np.dot(k[i],rvector[n+1]))*H_template[n+1].T 
            E = np.linalg.eigvals(H)
            E = np.sort(E.real)    
            Energy=np.append(Energy,E)
            
        self.bands_reproduce = np.reshape(Energy,[num_K,num_band])
        
    def scale_bands(self, bands_reference, max_energy, min_energy):
        num_k, num_b = bands_reference.shape
        x_points = np.arange(num_k)
        number=0   #用来提示当前是第几个能带
        final_index=0
        max_e=0
        min_e=0
        fig = plt.figure()
        for i in range(num_b):
            if(np.sum((bands_reference[:, i]>min_energy) & (bands_reference[:, i]<max_energy))>0):
                number+=1
                final_index=i
                if(number==1):
                    plt.plot(x_points, bands_reference[:, i], color='r', label='band_index'+str(i+1))
                else:
                    plt.plot(x_points, bands_reference[:, i], color='b')
                if(max_e<np.max(bands_reference[:, i])):
                    max_e = np.max(bands_reference[:, i])
                if(min_e>np.min(bands_reference[:, i])):
                    min_e = np.min(bands_reference[:, i])
        plt.plot(x_points, bands_reference[:, final_index], color='y', label='band_index'+str(final_index+1))
        plt.xlim(x_points[0], x_points[-1])
        plt.ylim(min_e - 0.5, max_e + 0.5)
        
        font = {'family': 'Times New Roman',
                'weight': 'normal',
                'size': 12,
                }
        
        from collections import OrderedDict
        handles, labels = plt.gca().get_legend_handles_labels()
        by_label = OrderedDict(zip(labels, handles))
        plt.legend(by_label.values(), by_label.keys(), prop=font)
        plt.savefig("./temp/temp.jpg")   #存储到临时文档
        plt.close()
        
    def linetextActivated(self, msg):   #加一个确认按钮
        #需要判断发送信息源的控件,据此来进行相应的判断
        source = self.sender()
        if(source == self.btn):
            self.press1=True
        elif(source == self.max_linetxt):
            self.press1=False
            self.press2=False
            self.D1_t1=True
            self.maxtext=msg
        elif(source == self.min_linetxt):
            self.press1=False
            self.press2=False
            self.D1_t2=True
            self.mintext=msg
        elif(source == self.btn2):
            self.press2=True
        elif(source == self.max_E_linetxt):
            self.press1=False
            self.press2=False
            self.D2_t1=True
            self.maxEtext=msg
        else:                                 #信息源来自最小
            self.press1=False
            self.press2=False
            self.D2_t2=True
            self.minEtext=msg
            
        if self.press1:
            if(self.D1_t1 and self.D1_t2 and  #在输入了的前提下
               is_number2(self.maxtext) and is_number2(self.mintext) and
              eval(self.maxtext)>eval(self.mintext) and eval(self.mintext)>0):   #两个都输入了,并且正确
                self.band_state=True   #意味着已经选择了能带
                self.dialog.state=True
                #删去临时文件
                self.min_refer_index=eval(self.mintext)-1
                self.max_refer_index=eval(self.maxtext)
                self.dialog.close()   #将对话框关闭
            else:
                QMessageBox.question(self.dialog, 'Error',
                "please enter a minimum or maxmum number correctly!", QMessageBox.Ok)
                self.press1=False
                
        if self.press2:
            if(self.D2_t1 and self.D2_t2 and  #在输入了的前提下
               is_number(self.maxEtext) and is_number(self.minEtext) and
                   eval(self.maxEtext)>eval(self.minEtext)):   #两个都输入了,并且正确
                self.scale_bands(self.reference,eval(self.maxEtext),eval(self.minEtext))
                self.label.setPixmap(QPixmap("./temp/temp.jpg"))   
            else:
                QMessageBox.question(self.dialog, 'Error',
                "please enter a minimum or maxmum number correctly!", QMessageBox.Ok)
                self.press2=False
                
    def linetextActivated2(self, msg):   #加一个确认按钮
        #需要判断text中的内容,并将其转化成小数形式,其余形式返回错误
        source = self.sender()
        if(source == self.btn):
            self.press3=True
        elif(source == self.max_linetxt):
            self.press3=False
            self.press4=False
            self.D1_t1=True
            self.maxtext2=msg
        elif(source == self.min_linetxt):
            self.press3=False
            self.press4=False
            self.D1_t2=True
            self.mintext2=msg
        elif(source == self.btn2):
            self.press4=True
        elif(source == self.max_E_linetxt):
            self.press3=False
            self.press4=False
            self.D2_t1=True
            self.maxEtext2=msg
        else:
            self.press3=False
            self.press4=False
            self.D2_t2=True
            self.minEtext2=msg
        
        if self.press3:
            if(self.D1_t1 and self.D1_t2 and  #在输入了的前提下
               is_number2(self.maxtext2) and is_number2(self.mintext2) and
               eval(self.maxtext2)>eval(self.mintext2) and eval(self.mintext2)>0
               and eval(self.maxtext2)-eval(self.mintext2)+1==self.num_fitband):   #两个都输入了,并且正确
                self.template_state=True   #意味着已经选择了能带
                self.dialog2.state=True
                #删去临时文件
                self.min_index=eval(self.mintext2)-1
                self.max_index=eval(self.maxtext2)
                self.dialog2.close()   #将对话框关闭
            elif(eval(self.maxtext2)-eval(self.mintext2)+1!=self.num_fitband):
                self.parameter_error3()
            else:
                QMessageBox.question(self.dialog2, 'Error',
                "please enter a minimum or maxmum number correctly!", QMessageBox.Ok)
                self.press3=False
                
        if self.press4:
            if(self.D2_t1 and self.D2_t2 and  #在输入了的前提下
              is_number(self.maxEtext2) and is_number(self.minEtext2) and
              eval(self.maxEtext2)>eval(self.minEtext2)):   #两个都输入了,并且正确
                self.scale_bands(self.bands_reproduce,eval(self.maxEtext2),eval(self.minEtext2))
                self.label.setPixmap(QPixmap("./temp/temp.jpg"))
            else:
                QMessageBox.question(self.dialog2, 'Error',
                "please enter a minimum or maxmum number correctly!", QMessageBox.Ok) 
                self.press4=False

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Mainwindow()
    sys.exit(app.exec_())