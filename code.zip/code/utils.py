# -*- coding: utf-8 -*-
"""
Created on Mon May 16 08:51:02 2022

@author: hu
"""
from PyQt5.QtWidgets import (QMessageBox, QDialog)

class Dialog(QDialog):
    """对QDialog类重写，实现一些功能"""
    
    def __init__(self, state):
        super(Dialog, self).__init__()
        self.state = state

    def closeEvent(self, event):
        """
        重写closeEvent方法，实现dialog窗体关闭时执行一些代码
        :param event: close()触发的事件
        :return: None
        """
        if(self.state==False):
            reply = QMessageBox.question(self,
                                        'Selection process exit',
                                        "Are you sure you want to quit？",
                                        QMessageBox.Yes | QMessageBox.No,
                                        QMessageBox.No)
            if reply ==QMessageBox.Yes:
                event.accept()
            else:
                event.ignore()
                
def is_number(s):
    try:  # 如果能运行float(s)语句，返回True（字符串s是浮点数）
        float(s)
        return True
    except ValueError:  # ValueError为Python的一种标准异常，表示"传入无效的参数"
        pass  # 如果引发了ValueError这种异常，不做任何事情（pass：不做任何事情，一般用做占位语句）
    try:
        import unicodedata  # 处理ASCii码的包
        unicodedata.numeric(s)  # 把一个表示数字的字符串转换为浮点数返回的函数
        return True
    except (TypeError, ValueError):
        pass
    return False 

def is_number2(s):
    try:  # 如果能运行int(s)语句，返回True（字符串s是整数）
        int(s)
        return True
    except ValueError:  # ValueError为Python的一种标准异常，表示"传入无效的参数"
        pass  # 如果引发了ValueError这种异常，不做任何事情（pass：不做任何事情，一般用做占位语句）
    try:
        import unicodedata  # 处理ASCii码的包
        unicodedata.numeric(s)  # 把一个表示数字的字符串转换为浮点数返回的函数
        return True
    except (TypeError, ValueError):
        pass
    return False        