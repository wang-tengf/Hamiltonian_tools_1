# -*- coding: utf-8 -*-
"""
Created on Mon May 16 09:01:02 2022

@author: hu
"""
from PyQt5.QtWidgets import (QHBoxLayout, QVBoxLayout, QFrame, QProgressBar,
QLabel, QLCDNumber)

class ProgressBoard(QFrame):
    def __init__(self, parent):
        super().__init__(parent)
 
        self.initBoard()
 
    def initBoard(self):
        
        self.pbar = QProgressBar(self)
        self.pbar.setGeometry(90, 10, 400, 30)
        
        self.label1 = QLabel(self)
        self.label1.setText("Epochs:")
        self.label1.setGeometry(10, 10, 80, 30)
        
        self.label2 = QLabel(self)
        self.label2.setText("Loss:")
        self.label2.setGeometry(10, 10, 80, 30)
        
        self.label3 = QLabel(self)
        self.label3.setText("Rvector:")
        self.label3.setGeometry(10, 10, 80, 30)
        
        self.status_label = QLabel(self)
        self.status_label.setText("Setting...") #三种状态：setting...;processing...;finished
        self.status_label.setGeometry(10, 10, 80, 30)
        
        self.rvector_label = QLabel(self)
        self.rvector_label.setText("...") #三种状态：setting...;processing...;finished
        self.rvector_label.setGeometry(10, 10, 80, 30)
        
        self.lcd = QLCDNumber(8,self)   #允许显示8位有效数字,对LED来说,科学表示法可以显示小数点后两位数字
        self.lcd.setFixedSize(400, 70)
        
        hbox0 = QHBoxLayout() #添加水平布局
        hbox0.addStretch(1)
        hbox0.addWidget(self.label3)
        hbox0.addWidget(self.rvector_label)
        hbox0.addStretch(1)
        
        hbox1 = QHBoxLayout() #添加水平布局
        hbox1.addWidget(self.label1)
        hbox1.addWidget(self.pbar)
        
        hbox2 = QHBoxLayout() #添加水平布局
        hbox2.addStretch(1)
        hbox2.addWidget(self.label2)
        hbox2.addWidget(self.lcd)
        hbox2.addStretch(1)
        
        hbox3 = QHBoxLayout() #添加水平布局
        hbox3.addStretch(1)
        hbox3.addWidget(self.status_label)
        hbox3.addStretch(1)
 
        vbox = QVBoxLayout()
        vbox.addStretch(1)
        vbox.addLayout(hbox0)
        vbox.addStretch(1)
        vbox.addLayout(hbox1)
        vbox.addStretch(1)
        vbox.addLayout(hbox2)
        vbox.addStretch(1)
        vbox.addLayout(hbox3)
        vbox.addStretch(1)
       
        self.setLayout(vbox)  
        self.show()
        
    def show_progress(self, value):  #需要知道max_epoch数为多少
    #progress bar只接受整数类型的数据并且限制从0到100
        self.pbar.setValue(value)   #修改后的step显示到进度条上
    
    def show_loss(self, loss):
        self.lcd.display(loss)
    
    def show_rvector(self, dimension):
        if(dimension=="..."):
            self.rvector_label.setText(dimension)
        else:
            temp=""
            for i in range(dimension.shape[0]-1):
                if(i==dimension.shape[0]//2):
                    temp=temp+str(dimension[i])+","+"\n"
                else:
                    temp=temp+str(dimension[i])+", "
            temp=temp+str(dimension[i+1])
            self.rvector_label.setText(temp)
            
    
    def show_label(self, value):   #用来显示当前进展阶段
        if(value==0):
            self.status_label.setText("Setting...")
        elif(value==1):
            self.status_label.setText("Processing...")
        elif(value==2):
            self.status_label.setText("Paused")
        else:
            self.status_label.setText("Finished")
        